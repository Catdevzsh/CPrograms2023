 
#include <stdio.h>
#include <stdlib.h>
/// Write hello world
int main()
{
    printf("Hello world!");
    return 0;
}
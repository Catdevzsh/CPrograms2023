// Write a calculator program that asks the user to enter two numbers, obtains the two numbers from the user, then prints the sum, product, difference, and quotient of the two numbers.

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num1, num2, sum, product, difference, quotient;
    printf("Enter two numbers: ");
    scanf("%d %d", &num1, &num2);
    sum = num1 + num2;
    product = num1 * num2;
    difference = num1 - num2;
    quotient = num1 / num2;
    printf("Sum is %d\n", sum);
    printf("Product is %d\n", product);
    printf("Difference is %d\n", difference);
    printf("Quotient is %d\n", quotient);
    return 0;
}

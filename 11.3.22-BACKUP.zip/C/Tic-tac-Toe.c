#include <stdio.h>
#include <stdlib.h>

void printBoard(int board[3][3])
{
    printf("\n\n\n");
    printf(" %d | %d | %d \n", board[0][0], board[0][1], board[0][2]);
    printf("-----------\n");
    printf(" %d | %d | %d \n", board[1][0], board[1][1], board[1][2]);
    printf("-----------\n");
    printf(" %d | %d | %d \n", board[2][0], board[2][1], board[2][2]);
}

int main()
{
    int player = 1; // Current player
    int winner = 0; // Winner: 0 = No winner, 1 = Player 1, 2 = Player 2
    int choice; // Choice of the player
    int i, j; // Loop variables
    int board[3][3] = {0}; // Tic Tac Toe board

    printf("Tic Tac Toe\n\n");

    // The game is played 3 times
    for(i=0; i<3; i++)
    {
        // Each player makes a move 3 times
        for(j=0; j<3; j++)
        {
            printf("Player %d, enter your choice: ", player);
            scanf("%d", &choice);

            // Check if the input is valid
            if(choice >= 1 && choice <= 9 && board[(choice-1)/3][(choice-1)%3] == 0)
            {
                board[(choice-1)/3][(choice-1)%3] = player;
            }
            else
            {
                printf("Invalid input, please try again.\n");
                j--;
                continue;
            }

            // Check if anyone won
            for(int k=0; k<3; k++)
            {
                if(board[k][0] == board[k][1] && board[k][1] == board[k][2])
                {
                    winner = board[k][0];
                }

                if(board[0][k] == board[1][k] && board[1][k] == board[2][k])
                {
                    winner = board[0][k];
                }
            }

            // Check for diagonal winners
            if(board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0)
            {
                winner = board[0][0];
            }

            if(board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0)
            {
                winner = board[0][2];
            }

            // Print the board
            printBoard(board);

            // If there is a winner, break out of the loops
            if(winner != 0)
            {
                break;
            }

            // Change the player
            if(player == 1)
            {
                player = 2;
            }
            else
            {
                player = 1;
            }
        }

        // If there is a winner, break out of the loop
        if(winner != 0)
        {
            break;
        }
    }

    // Print the results
    if(winner == 0)
    {
        printf("\nDraw!\n");
    }
    else
    {
        printf("\nPlayer %d wins!\n", winner);
    }

    return 0;
}

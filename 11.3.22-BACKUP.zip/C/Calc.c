
#include <stdio.h>
#include <stdlib.h>

int main() { 
   float num1, num2, result; 
   char op; 
   printf("Enter two numbers: "); 
   scanf("%f %f", &num1, &num2); 
   printf("Enter an operator (+, -, *, /): "); 
   scanf(" %c", &op); 
   switch (op) { 
      case '+': 
         result = num1 + num2; 
         break; 
      case '-': 
         result = num1 - num2; 
         break; 
      case '*': 
         result = num1 * num2; 
         break; 
      case '/': 
         result = num1 / num2; 
         break; 
      default: 
         printf("Invalid operator"); 
   } 
   printf("%.1f %c %.1f = %.1f", num1, op, num2, result); 
   return 0; 
}